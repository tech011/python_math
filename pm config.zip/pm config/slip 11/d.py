def absolute(n):
    if n < 0:
        return -n
    return n

num = -15
print("Absolute value:", absolute(num))
