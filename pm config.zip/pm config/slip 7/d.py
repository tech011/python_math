sum_values = 0  
count = 0  

for i in range(50, 101):
    sum_values = sum_values + i  
    count = count + 1  

average = sum_values / count  
print("Average:", average)
