num = 1  

while num <= 20:
    if num % 2 != 0:
        print("Square of", num, "is", num * num)
    num = num + 1
