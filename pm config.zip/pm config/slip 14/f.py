n = 5  
product = 1  
num = 1  

while num <= n:
    product = product * num  
    num = num + 1  

print("Product of first", n, "natural numbers:", product)
