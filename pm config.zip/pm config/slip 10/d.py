def absolute(n):
    if n < 0:
        return -n
    return n

num = -7
print("Absolute value:", absolute(num))
