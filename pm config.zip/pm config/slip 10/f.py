Wonderful = "wonderful"

def display():
    bad = "bad"
    print("Python is", bad)
    print("Python is", Wonderful)

display()
