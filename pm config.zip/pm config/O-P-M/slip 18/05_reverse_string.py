def revers_string(string):
    reve_str = string[::-1]
    print("your string = ",string)
    print("reverse sting = ",reve_str)
    
string = input('Ente the string:-')
revers_string(string)



# Ente the string:-om
# your string =  om
# reverse sting =  mo