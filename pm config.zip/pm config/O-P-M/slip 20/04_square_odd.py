print("\nsquare of odd number 1 to 20:-")
for i in range(20):
    if i %2 == 1:
        print(f"{i} ^ 2 = {i*i}")