
def add_ing(string):
    print("your string:-",string);
    string = string + 'ing'
    print("add ing=",string)
    
add_ing('play')