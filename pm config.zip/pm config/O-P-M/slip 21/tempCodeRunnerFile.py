if f(x0)*f(x1) > 0.0:
        print("take the different values")
        return