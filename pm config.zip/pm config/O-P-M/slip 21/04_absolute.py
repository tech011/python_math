# Taking user input
n = float(input("Enter a real number: "))

# Finding absolute value
absolute_value = abs(n)

# Displaying the result
print("The absolute value of", n, "is", absolute_value)
