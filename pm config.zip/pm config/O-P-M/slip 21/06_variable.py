
wonderful = "wonderful"

def display_message():

    bad = "bad"
    
    
    print("Python is", bad)        
    print("Python is", wonderful)  

display_message()
